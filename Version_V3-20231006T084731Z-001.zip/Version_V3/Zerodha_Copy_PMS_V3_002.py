import sys, os
from time import sleep

try:
    Version = sys.version[:4]
except Exception as e:
    print(f"{e}")
    pass
    
if Version != "3.11":
    Message = "This trade tool will work with python latest version 3.11 only, so please upgrade python from installed version " + str(Version) + "to python 3.11"
    print(Message)
    sleep(10)
    sys.exit()
    
try:
    import psutil
except (ModuleNotFoundError, ImportError):
    print("psutil module not found")
    os.system(f"{sys.executable} -m pip install -U psutil")
finally:
    import psutil

    
try:
    import requests
except (ModuleNotFoundError, ImportError):
    print("requests module not found")
    os.system(f"{sys.executable} -m pip install -U requests")
finally:
    import requests

try:
    import pyotp
except (ModuleNotFoundError, ImportError):
    print("pyotp module not found")
    os.system(f"{sys.executable} -m pip install -U pyotp")
finally:
    import pyotp
    
try:
    import xlwings as xw
except (ModuleNotFoundError, ImportError):
    print("xlwings module not found")
    os.system(f"{sys.executable} -m pip install -U xlwings")
finally:
    import xlwings as xw

try:
    import pandas as pd
except (ModuleNotFoundError, ImportError):
    print("pandas module not found")
    os.system(f"{sys.executable} -m pip install -U pandas")
finally:
    import pandas as pd

try:
    import sourcedefender
except (ModuleNotFoundError, ImportError):
    print("sourcedefender module not found")
    os.system(f"{sys.executable} -m pip install -U sourcedefender")
finally:
    import sourcedefender

try:
    import scipy
except (ModuleNotFoundError, ImportError):
    print("scipy module not found")
    os.system(f"{sys.executable} -m pip install -U scipy")
finally:
    import scipy

try:
    from selenium import webdriver
except (ModuleNotFoundError, ImportError):
    print("selenium module not found")
    os.system(f"{sys.executable} -m pip install -U selenium")
finally:
    from selenium import webdriver

try:
    from webdriver_manager.chrome import ChromeDriverManager
except (ModuleNotFoundError, ImportError):
    print("webdriver_manager module not found")
    os.system(f"{sys.executable} -m pip install -U webdriver_manager")
finally:
    from webdriver_manager.chrome import ChromeDriverManager


try:
    import kiteconnect
except (ModuleNotFoundError, ImportError):
    print("kiteconnect module not found")
    os.system(f"{sys.executable} -m pip install -U kiteconnect")
finally:
    import kiteconnect

try:
    import numpy as np 
except (ModuleNotFoundError, ImportError):
    print("numpy module not found")
    os.system(f"{sys.executable} -m pip install -U numpy")
finally:
    import numpy as np 
    
try:
    from googleapiclient import discovery
except (ModuleNotFoundError, ImportError):
    print("googleapiclient module not found")
    os.system(f"{sys.executable} -m pip install -U google-api-python-client")
finally:
    from googleapiclient import discovery
    
try:
    import gspread
except (ModuleNotFoundError, ImportError):
    print("gspread module not found")
    os.system(f"{sys.executable} -m pip install -U gspread")
finally:
    import gspread

try:
    from gspread_dataframe import set_with_dataframe
except (ModuleNotFoundError, ImportError):
    print("gspread_dataframe module not found")
    os.system(f"{sys.executable} -m pip install -U gspread_dataframe")
finally:
    from gspread_dataframe import set_with_dataframe
    
try:
    from oauth2client.service_account import ServiceAccountCredentials
except (ModuleNotFoundError, ImportError):
    print("oauth2client module not found")
    os.system(f"{sys.executable} -m pip install -U oauth2client")
finally:
    from oauth2client.service_account import ServiceAccountCredentials

try:
    from tzlocal import get_localzone
except (ModuleNotFoundError, ImportError):
    print("tzlocal module not found")
    os.system(f"{sys.executable} -m pip install -U tzlocal")
finally:
    from tzlocal import get_localzone
    
try:
    import sourcedefender
    import PT_Copy_PMS_Zerodha_Core_V3_002
except Exception as e:
    print(f"PT_Copy_PMS_Zerodha_Core_V3_002.pye file not found/corrupted, please download the latest file from tinyurl.com/pythontrader : {e}")

    